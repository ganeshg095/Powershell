# AD-Monitor Group membership

This script has been moved to its own repository