# PowerShell

This repository is used for all my public scripts.
Let me know if you have any issues using them, always space for improvement
Feel free to fork

* [Blog](https://lazywinadmin.com)
* [Twitter @LazyWinAdmin](https://twitter.com/LazyWinAdmin)
