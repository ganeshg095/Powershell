Function clx {
    [System.Console]::SetWindowPosition(0, [System.Console]::CursorTop)
}